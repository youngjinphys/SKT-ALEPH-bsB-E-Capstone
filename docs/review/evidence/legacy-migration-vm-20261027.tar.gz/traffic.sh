#!/bin/bash
set -euo pipefail
query() { sudo ip netns exec aleph-client dig -b 192.168.44.20 @192.168.44.10 "$1" A "${@:2}" +time=2 +tries=1; }
for mode in udp tcp; do
  flags=(); [[ "$mode" == tcp ]] && flags=(+tcp)
  blocked=$(query account-session-verify.test "${flags[@]}")
  echo "$mode BLOCK $(echo "$blocked" | sed -n '/status:/p')"
  [[ "$blocked" == *'status: NXDOMAIN'* ]]
  allowed=$(query example.test "${flags[@]}")
  echo "$mode ALLOW $(echo "$allowed" | sed -n '/status:/p') $(echo "$allowed" | grep '192.0.2.42' | tail -1)"
  [[ "$allowed" == *'status: NOERROR'* && "$allowed" == *'192.0.2.42'* ]]
  if sudo ip netns exec aleph-client dig -b 192.168.44.200 @192.168.44.10 example.test A "${flags[@]}" +time=1 +tries=1 > /tmp/denied-$mode 2>&1; then
    echo "FAIL denied client $mode unexpectedly reached DNS"; exit 1
  fi
  echo "$mode DENIED expected timeout"
done
