#!/bin/bash
set -euo pipefail
newsrc=${1:?new source required}
out=${2:?output directory required}
mkdir -p "$out"
cd "$newsrc"
sudo nft -j -a list table inet aleph_dns > "$out/table-before.json"
sudo sha256sum /etc/aleph-dns/{policy.json,options.json,firewall.nft} /var/lib/aleph-dns/{state.json,active.conf} /etc/systemd/system/aleph-dns{,-firewall}.service > "$out/files-before.sha256"
if sudo python3 infra/edge/system_dns.py upgrade --apply > "$out/missing-adopt.log" 2>&1; then
  echo 'FAIL: missing adoption unexpectedly succeeded'; exit 1
fi
sudo nft -j -a list table inet aleph_dns > "$out/table-no-adopt.json"
cmp "$out/table-before.json" "$out/table-no-adopt.json"
sudo sha256sum /etc/aleph-dns/{policy.json,options.json,firewall.nft} /var/lib/aleph-dns/{state.json,active.conf} /etc/systemd/system/aleph-dns{,-firewall}.service > "$out/files-no-adopt.sha256"
cmp "$out/files-before.sha256" "$out/files-no-adopt.sha256"
systemctl is-active aleph-dns.service aleph-dns-firewall.service
sudo nft add chain inet aleph_dns external_conflict
sudo nft -j -a list table inet aleph_dns > "$out/table-with-conflict-before.json"
if sudo python3 infra/edge/system_dns.py upgrade --apply --adopt-legacy-table > "$out/conflict.log" 2>&1; then
  echo 'FAIL: conflicting table unexpectedly adopted'; exit 1
fi
sudo nft -j -a list table inet aleph_dns > "$out/table-with-conflict-after.json"
cmp "$out/table-with-conflict-before.json" "$out/table-with-conflict-after.json"
sudo sha256sum /etc/aleph-dns/{policy.json,options.json,firewall.nft} /var/lib/aleph-dns/{state.json,active.conf} /etc/systemd/system/aleph-dns{,-firewall}.service > "$out/files-conflict.sha256"
cmp "$out/files-before.sha256" "$out/files-conflict.sha256"
systemctl is-active aleph-dns.service aleph-dns-firewall.service
sudo nft delete chain inet aleph_dns external_conflict
sudo nft -j -a list table inet aleph_dns > "$out/table-restored.json"
cmp "$out/table-before.json" "$out/table-restored.json"
bash /tmp/traffic.sh
printf 'REJECTIONS_AND_RECOVERY_VERIFIED\n'
