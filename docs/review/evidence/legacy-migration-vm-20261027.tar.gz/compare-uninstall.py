import hashlib, pathlib, stat, tarfile, sys
archive=pathlib.Path(sys.argv[1]); original=pathlib.Path(sys.argv[2])
with tarfile.open(original) as old:
 for name in ('etc/aleph-dns','etc/aleph-dns/policy.json','var/lib/aleph-dns','var/lib/aleph-dns/state.json','var/lib/aleph-dns/active.conf'):
  member=old.getmember(name); rel=name.replace('etc/aleph-dns','config',1).replace('var/lib/aleph-dns','state',1); target=archive/rel; st=target.stat()
  print(name,'original',member.uid,member.gid,oct(member.mode),'backup',st.st_uid,st.st_gid,oct(stat.S_IMODE(st.st_mode)))
  assert (member.uid,member.gid,member.mode)==(st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))
  if member.isfile():
   data=old.extractfile(member).read(); print('sha',hashlib.sha256(data).hexdigest()); assert data==target.read_bytes()
print('UNINSTALL_BACKUP_BYTES_AND_METADATA_MATCH')
