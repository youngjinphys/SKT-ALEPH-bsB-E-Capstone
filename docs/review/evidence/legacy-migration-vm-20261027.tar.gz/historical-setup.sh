#!/bin/bash
set -euo pipefail
version=${1:?version}
cd /home/tester/$version
python3 scripts/build_campaign_policy.py > /home/tester/policy-$version.json
sudo python3 infra/edge/system_dns.py install --listen-ip 192.168.44.10 --interface aleph-lan --client-cidr 192.168.44.0/25 --upstream 127.0.0.1 --upstream-port 15353 --policy /home/tester/policy-$version.json --apply
systemctl is-active aleph-dns.service aleph-dns-firewall.service
sudo stat -c '%n %u:%g %a' /opt/aleph-dns/src
sudo nft -a list table inet aleph_dns
bash /home/tester/traffic.sh
sudo tar -C / -cpf /home/tester/$version-before.tar etc/aleph-dns var/lib/aleph-dns etc/systemd/system/aleph-dns.service etc/systemd/system/aleph-dns-firewall.service opt/aleph-dns
sudo chmod 644 /home/tester/$version-before.tar
sha256sum /home/tester/$version-before.tar
