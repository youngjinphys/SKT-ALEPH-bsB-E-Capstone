import hashlib, json, os, pathlib, stat, tarfile
archive=pathlib.Path('/var/backups/aleph-dns-migration-wh2c3578')
with tarfile.open('/home/tester/e946-before.tar') as old:
 for name in ['etc/aleph-dns','etc/aleph-dns/policy.json','var/lib/aleph-dns','var/lib/aleph-dns/state.json','var/lib/aleph-dns/active.conf','opt/aleph-dns/src']:
  member=old.getmember(name)
  rel=name.replace('etc/aleph-dns','config',1).replace('var/lib/aleph-dns','state',1).replace('opt/aleph-dns','code',1)
  target=archive/rel; st=target.stat()
  print(name, 'original', member.uid,member.gid,oct(member.mode), 'backup',st.st_uid,st.st_gid,oct(stat.S_IMODE(st.st_mode)))
  assert (member.uid,member.gid,member.mode)==(st.st_uid,st.st_gid,stat.S_IMODE(st.st_mode))
  if member.isfile():
   data=old.extractfile(member).read(); print('original sha',hashlib.sha256(data).hexdigest(),'backup sha',hashlib.sha256(target.read_bytes()).hexdigest()); assert data == target.read_bytes()
 oldstate=json.load(old.extractfile('var/lib/aleph-dns/state.json'))
 current=json.loads(pathlib.Path('/var/lib/aleph-dns/state.json').read_text())
 print('old state:',json.dumps(oldstate,sort_keys=True)); print('current state:',json.dumps(current,sort_keys=True))
 for key in ('policy','policy_sha256','config','config_sha256','blocked_count'): assert oldstate[key]==current[key],key
 print('BACKUP_BYTES_METADATA_AND_LIVE_STATE_SEMANTICS_MATCH')
