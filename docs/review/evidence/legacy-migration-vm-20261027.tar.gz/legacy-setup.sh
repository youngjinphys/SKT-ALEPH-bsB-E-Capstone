#!/bin/bash
set -euo pipefail
cd /home/tester/legacy
python3 scripts/build_campaign_policy.py > /home/tester/policy-second.json
PYTHONPATH=apps/dns-agent/src python3 -m dns_agent validate /home/tester/policy-second.json
sudo mkdir -p /etc/systemd/system/aleph-dns.service.d
printf '[Service]\nRestrictAddressFamilies=\nRestrictAddressFamilies=AF_UNIX AF_INET AF_INET6 AF_NETLINK\n' | sudo tee /etc/systemd/system/aleph-dns.service.d/legacy-netlink.conf
sudo systemctl daemon-reload
sudo python3 infra/edge/system_dns.py install --listen-ip 192.168.44.10 --interface aleph-lan --client-cidr 192.168.44.0/25 --upstream 127.0.0.1 --upstream-port 15353 --policy /home/tester/policy-second.json --apply
sudo rm /etc/systemd/system/aleph-dns.service.d/legacy-netlink.conf
sudo rmdir /etc/systemd/system/aleph-dns.service.d
sudo systemctl daemon-reload
systemctl is-active aleph-dns.service aleph-dns-firewall.service
sudo systemctl show aleph-dns.service -p DropInPaths
sudo stat -c '%n %u:%g %a' /opt/aleph-dns/src
sudo sha256sum /etc/aleph-dns/policy.json /var/lib/aleph-dns/state.json /var/lib/aleph-dns/active.conf
sudo nft -j -a list table inet aleph_dns
bash /home/tester/traffic.sh
sudo tar -C / -cpf /home/tester/legacy-second-before.tar etc/aleph-dns var/lib/aleph-dns etc/systemd/system/aleph-dns.service etc/systemd/system/aleph-dns-firewall.service opt/aleph-dns
sudo chmod 644 /home/tester/legacy-second-before.tar
sha256sum /home/tester/legacy-second-before.tar
